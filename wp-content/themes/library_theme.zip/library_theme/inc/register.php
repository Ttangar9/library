<div class="register-container">
	<div class="register_form">
		<h1>Регистрация</h1>
		<form action="#" method="post">
			<input type="text" id="user_name" placeholder="Имя">
			<input type="email"  id="user_email" placeholder="Эл.адрес">
			<input type="text"  id="user_ticket" placeholder="Номер билета">
			<input type="password"  id="user_pass" placeholder="Пароль">
			<p class="register_error"></p>
			<input type="submit" id="user_register_btn" value="Зарегестрироваться">
		</form>
	</div>
</div>