<form action="<?php wp_redirect( home_url() );?>">
	<label for="#">
		<input type="text" placeholder="Имя">
		<input type="text" placeholder="Фамилия">
		<input type="password" placeholder="Пароль">
		<input type="text" placeholder="Номер билета">
		<input type="text" placeholder="Эл.адрес">
		<input type="submit" value="Зарегестрироваться">
	</label>
</form>